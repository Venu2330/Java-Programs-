package test;

public class strings2 {

}
