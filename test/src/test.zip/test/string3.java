package test;

public class string3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name="Home and  Microsoft";
		int string_length=name.length();
		for(int i=1;i<string_length;i=i+2)
		System.out.print(name.charAt(i));
		//System.out.println(name.charAt(string_length-1));

	}

}
