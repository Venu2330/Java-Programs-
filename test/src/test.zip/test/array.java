package test;
import java.lang.Math;


public class array 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		//int[] arr=new int[12];
		int [] arr= {3,5,6,4,8,0,-1,23,15,10,17,19};
		int even=0;
		int odd=0,sqaure=0;
		int count1=0,countzero=0;
		//even index code 
		System.out.println("Even index values are");
		for(int i=0;i<arr.length;i+=2)
		{
			System.out.println(arr[i]);
		}
		//odd index code 
			System.out.println("Odd index values are");
			for(int i=1;i<arr.length;i+=2) 
			{
				System.out.println(arr[i]);
			}
			
		//printing even numbers
			System.out.println("Printing even numbers in the array:");
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i]%2==0)
				{ 
					 even++;//frequency of even numbers
				System.out.println(arr[i]);
				}
			}
			//printing odd numbers from the array
			System.out.println("Printing Odd numbers in the array:");
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i]%2!=0)
				{
					 odd++;//frequency of odd numbers
				System.out.println(arr[i]);
				}
			}
			//printing prime numbers from the array
			System.out.println("Printing prime numbers in the array:");
			for(int i=0;i<arr.length;i++)
			{ 
				//int k=arr[i];
				int count=0;
					if(arr[i]<=1)
						continue;
				for(int j=2;j<=arr[i]/2;j++)
				{
					if(arr[i]%j==0)
					{
						count=1;
						break;
					}
				}
				if(count==0)
				{ 	
					 count1++;//frequency of prime numbers
					System.out.println(arr[i]);
				}
			}
			
			//print the numbers in reverse order
			System.out.println("print the numbers in reverse order");
			for(int i=arr.length-1;i>=0;i--)
			{
				if(arr[i]==0)
				{
					countzero++;//frequency of zero
				}
				System.out.println(arr[i]);
			}
			//perfect squares
			System.out.println("Perfect squares");
			for(int i=0;i<arr.length;i++)
			{
				double t1=(int)(Math.sqrt(arr[i]));
				if(arr[i]==t1*t1)
				{
					sqaure++;
					System.out.println(arr[i]);
				}
			}
			//sqaure of all numbers in the array
			System.out.println("sqaure of all numbers in the array");
			for(int i=0;i<arr.length;i++)
			{
				int s=arr[i]*arr[i];
				System.out.println(s);
			}
			
			//Negative numbers in the array
			System.out.println("Negative numbers in the array");
			for(int i=0;i<arr.length;i++)
			{
				if(arr[i]<0)
				{
				System.out.println(arr[i]);
				}
			}
			//frequences are printing here 
			System.out.println("Even numbers in the array="+even);
			System.out.println("ODD numbers in the array="+odd);
			System.out.println("prime numbers in the array="+count1);
			System.out.println(" number of zeros in the array="+countzero);
			System.out.println("Square numbers in the array="+sqaure);
	}
}
