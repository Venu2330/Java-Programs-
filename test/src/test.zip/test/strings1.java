package test;
//import java.util.*;

public class strings1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="Hello world";
//		Scanner sc=new Scanner(System.in);
		char ch=input.charAt(6);
		System.out.println(ch);

	}

}