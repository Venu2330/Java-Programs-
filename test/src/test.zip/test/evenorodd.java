package test;

public class evenorodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=11;
		if(num%2==0)
		{
			System.out.println("even number");
		}
		else
		{
			System.out.println("odd number");
		}

	}

}
